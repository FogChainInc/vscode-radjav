# Running the examples on desktop
Install the RadJavVM from: https://github.com/HigherEdgeSoftware/RadJav/releases

Then double click on exampleBrowser.xrj to execute the example browser.

# Running the HTML5 examples
Either copy the examples directory to a web server thats accessible to your device, or run html5server.xrj, then click "Start Server". Finally click View Examples to see them run in your default web browser.